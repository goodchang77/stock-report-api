# yfinance-api for Zeabur

A simple FastAPI project to fetch stock info from yfinance and expose it as an API.

## Endpoint

GET `/company?ticker=AAPL`

## Deploy

Deploy this repo to [Zeabur](https://zeabur.com) with Python/FastAPI template.